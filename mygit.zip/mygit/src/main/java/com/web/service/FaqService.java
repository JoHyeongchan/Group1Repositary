package com.web.service;



public interface FaqService  extends ObjectService{


}
