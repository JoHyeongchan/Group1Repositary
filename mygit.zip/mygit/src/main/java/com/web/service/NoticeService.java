package com.web.service;



public interface NoticeService extends ObjectService{


}
