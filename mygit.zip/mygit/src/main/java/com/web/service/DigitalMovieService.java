package com.web.service;

public interface DigitalMovieService extends ObjectService {


}
