package com.web.service;

public interface QnaService extends ObjectService{

	

	int insertReplyProcess(Object obj);

	

	//int InsertReply(Object obj);

	//void updateReply(int qGroup, int qOrigin);

}
