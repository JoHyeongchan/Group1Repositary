package com.web.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.web.dao.UsergalFrameDAO;

public interface UsergalFrameService extends ObjectService{


	
}
