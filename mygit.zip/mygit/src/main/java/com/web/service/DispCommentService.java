package com.web.service;


public interface DispCommentService extends ObjectService{

	
}
