package com.web.service;

public interface CollectionService extends ObjectService{

}
