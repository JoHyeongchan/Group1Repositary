package com.web.vo;

public class PostReservationVO {
	String rid, rtitle, rdate, rtime, rnum, id;
	int rcancel, rvisited;

	public String getRid() {
		return rid;
	}
	public void setRid(String rid) {
		this.rid = rid;
	}
	public String getRtitle() {
		return rtitle;
	}
	public void setRtitle(String rtitle) {
		this.rtitle = rtitle;
	}
	public String getRdate() {
		return rdate;
	}
	public void setRdate(String rdate) {
		this.rdate = rdate;
	}
	public String getRtime() {
		return rtime;
	}
	public void setRtime(String rtime) {
		this.rtime = rtime;
	}
	public String getRnum() {
		return rnum;
	}
	public void setRnum(String rnum) {
		this.rnum = rnum;
	}
	public int getRcancel() {
		return rcancel;
	}
	public void setRcancel(int rcancel) {
		this.rcancel = rcancel;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getRvisited() {
		return rvisited;
	}
	public void setRvisited(int rvisited) {
		this.rvisited = rvisited;
	}
}
