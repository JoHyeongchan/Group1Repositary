package com.web.vo;

public class UserGalFrameVO {

	String galleryId,galleryUserId,galleryTitle,galleryHits,galleryDate,galleryThumbNail;
	String galleryDesc;
	
	int hits,rno;
	public String getGalleryId() {
		return galleryId;
	}
	public void setGalleryId(String galleryId) {
		this.galleryId = galleryId;
	}
	public String getGalleryUserId() {
		return galleryUserId;
	}
	public void setGalleryUserId(String galleryUserId) {
		this.galleryUserId = galleryUserId;
	}
	public String getGalleryTitle() {
		return galleryTitle;
	}
	public void setGalleryTitle(String galleryTitle) {
		this.galleryTitle = galleryTitle;
	}
	public String getGalleryHits() {
		return galleryHits;
	}
	public void setGalleryHits(String galleryHits) {
		this.galleryHits = galleryHits;
	}
	public String getGalleryDate() {
		return galleryDate;
	}
	public void setGalleryDate(String galleryDate) {
		this.galleryDate = galleryDate;
	}
	public String getGalleryThumbNail() {
		return galleryThumbNail;
	}
	public void setGalleryThumbNail(String galleryThumbNail) {
		this.galleryThumbNail = galleryThumbNail;
	}
	public int getHits() {
		return hits;
	}
	public void setHits(int hits) {
		this.hits = hits;
	}
	public int getRno() {
		return rno;
	}
	public void setRno(int rno) {
		this.rno = rno;
	}
	public String getGalleryDesc() {
		return galleryDesc;
	}
	public void setGalleryDesc(String galleryDesc) {
		this.galleryDesc = galleryDesc;
	}
	
	
	
}
