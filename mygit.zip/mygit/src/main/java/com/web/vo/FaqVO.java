package com.web.vo;

public class FaqVO {
		private String faId,faTitle,faContent,faCategory;

		public String getFaId() {
			return faId;
		}

		public void setFaId(String faId) {
			this.faId = faId;
		}

		public String getFaTitle() {
			return faTitle;
		}

		public void setFaTitle(String faTitle) {
			this.faTitle = faTitle;
		}

		public String getFaContent() {
			return faContent;
		}

		public void setFaContent(String faContent) {
			this.faContent = faContent;
		}

		public String getFaCategory() {
			return faCategory;
		}

		public void setFaCategory(String faCategory) {
			this.faCategory = faCategory;
		}
	
		
}
